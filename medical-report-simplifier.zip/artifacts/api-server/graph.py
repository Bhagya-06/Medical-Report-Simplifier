"""
LangGraph Workflow Graph

This module builds and compiles the LangGraph workflow for the
Medical Report Simplifier. It connects all 7 nodes in sequence.

LangGraph concepts demonstrated here:
- StateGraph: The main graph object that orchestrates node execution
- add_node: Registers a function as a named graph node
- add_edge: Connects nodes in sequence (or conditionally)
- set_entry_point: Declares which node executes first
- set_finish_point: Declares which node is last
- compile: Finalizes the graph for execution

The graph topology:
  START
    ↓
  extract_findings     (Node 1)
    ↓
  medical_terms        (Node 2)
    ↓
  abnormal_values      (Node 3)
    ↓
  simplification       (Node 4)
    ↓
  patient_summary      (Node 5)
    ↓
  self_review          (Node 6)
    ↓
  final_output         (Node 7)
    ↓
  END
"""

from langgraph.graph import StateGraph, END
from state import MedicalReportState
from nodes import (
    extract_findings_node,
    medical_terms_node,
    abnormal_values_node,
    simplification_node,
    patient_summary_node,
    self_review_node,
    final_output_node,
)


def build_graph():
    """
    Build and compile the LangGraph workflow.

    Returns a compiled graph that can be invoked with an initial state.

    LangGraph concept: The compiled graph is a runnable object.
    Call graph.invoke(initial_state) to execute the full workflow.
    """

    # Create a new StateGraph with our state schema
    graph = StateGraph(MedicalReportState)

    # Register each node function with a name
    # LangGraph concept: Node names are used to reference nodes in edges
    graph.add_node("extract_findings", extract_findings_node)
    graph.add_node("medical_terms", medical_terms_node)
    graph.add_node("abnormal_values", abnormal_values_node)
    graph.add_node("simplification", simplification_node)
    graph.add_node("patient_summary", patient_summary_node)
    graph.add_node("self_review", self_review_node)
    graph.add_node("final_output", final_output_node)

    # Set the entry point — this is the first node that runs
    graph.set_entry_point("extract_findings")

    # Add sequential edges — after Node N completes, Node N+1 starts
    # LangGraph concept: Edges define the flow between nodes.
    # You can also use conditional_edges() for branching logic.
    graph.add_edge("extract_findings", "medical_terms")
    graph.add_edge("medical_terms", "abnormal_values")
    graph.add_edge("abnormal_values", "simplification")
    graph.add_edge("simplification", "patient_summary")
    graph.add_edge("patient_summary", "self_review")
    graph.add_edge("self_review", "final_output")

    # Set the finish point — after this node, graph execution ends
    graph.add_edge("final_output", END)

    # Compile the graph — this validates the structure and returns an executable
    compiled = graph.compile()

    return compiled


# Build the graph once at module import time for reuse across requests
medical_report_graph = build_graph()
