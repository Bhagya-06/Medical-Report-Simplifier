"""
PDF Processor

Extracts plain text from uploaded PDF files using pypdf.
"""

import io
from pypdf import PdfReader


def extract_text_from_pdf(file_bytes: bytes) -> str:
    """
    Extract all text from a PDF file given its raw bytes.

    Args:
        file_bytes: Raw bytes of the PDF file

    Returns:
        Extracted text as a single string

    Raises:
        ValueError: If the PDF cannot be read or has no extractable text
    """
    try:
        reader = PdfReader(io.BytesIO(file_bytes))

        if len(reader.pages) == 0:
            raise ValueError("The PDF file appears to be empty (no pages found).")

        text_parts = []
        for page_num, page in enumerate(reader.pages):
            page_text = page.extract_text()
            if page_text:
                text_parts.append(page_text.strip())

        full_text = "\n\n".join(text_parts)

        if not full_text.strip():
            raise ValueError(
                "No readable text could be extracted from this PDF. "
                "The file may contain only images or scanned content."
            )

        return full_text

    except ValueError:
        raise
    except Exception as e:
        raise ValueError(f"Failed to process PDF: {str(e)}")
