"""
Medical Report Simplifier AI — FastAPI Backend

This is the main FastAPI application. It exposes two endpoints:
  POST /api/analyze  — runs the full LangGraph workflow on a pasted report
  POST /api/upload   — extracts text from an uploaded PDF
  GET  /api/healthz  — health check

The API key is passed by the user per-request and never stored.
"""

import os
import logging
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from graph import medical_report_graph
from state import MedicalReportState
from pdf_processor import extract_text_from_pdf

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Medical Report Simplifier AI",
    description="LangGraph-powered medical report analysis API",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─────────────────────────────────────────────────────────────────────────────
# Request / Response Models
# ─────────────────────────────────────────────────────────────────────────────

class AnalyzeRequest(BaseModel):
    api_key: str
    report_text: str


class UploadResponse(BaseModel):
    text: str


# ─────────────────────────────────────────────────────────────────────────────
# Routes
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/api/healthz")
def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


@app.post("/api/analyze")
async def analyze_report(request: AnalyzeRequest):
    """
    Run the full LangGraph workflow on a medical report.

    The user provides their own OpenAI API key per-request.
    The key is used only for this request and never stored.

    LangGraph concept: We invoke the compiled graph with an initial state.
    The graph runs all 7 nodes in sequence and returns the final state.
    """
    if not request.api_key or not request.api_key.strip():
        raise HTTPException(status_code=400, detail="OpenAI API key is required")

    if not request.report_text or not request.report_text.strip():
        raise HTTPException(status_code=400, detail="Report text is required")

    if len(request.report_text) > 50000:
        raise HTTPException(
            status_code=400,
            detail="Report text is too long (max 50,000 characters)"
        )

    # Build the initial state for the LangGraph workflow
    # LangGraph concept: All fields not yet populated are set to None or []
    initial_state: MedicalReportState = {
        "original_report": request.report_text.strip(),
        "api_key": request.api_key.strip(),
        "extracted_findings": None,
        "medical_terms": None,
        "abnormal_values": None,
        "simplified_explanations": None,
        "patient_summary": None,
        "review_notes": None,
        "final_output": None,
        "workflow_steps": [],
    }

    try:
        logger.info("Starting LangGraph workflow for medical report analysis")

        # Invoke the compiled LangGraph — this runs all 7 nodes in sequence
        # LangGraph concept: graph.invoke() runs the full workflow synchronously
        # and returns the final state after all nodes have executed.
        final_state = medical_report_graph.invoke(initial_state)

        logger.info("LangGraph workflow completed successfully")

        # Return the assembled final output
        result = final_state.get("final_output", {})
        if not result:
            raise HTTPException(status_code=500, detail="Workflow produced no output")

        return result

    except HTTPException:
        raise
    except Exception as e:
        error_msg = str(e)
        logger.error(f"LangGraph workflow failed: {error_msg}")

        # Surface a friendly error to the user
        if "api_key" in error_msg.lower() or "authentication" in error_msg.lower() or "invalid_api_key" in error_msg.lower():
            raise HTTPException(
                status_code=400,
                detail="Invalid OpenAI API key. Please check your key and try again."
            )
        elif "rate_limit" in error_msg.lower():
            raise HTTPException(
                status_code=429,
                detail="OpenAI rate limit reached. Please wait a moment and try again."
            )
        elif "quota" in error_msg.lower():
            raise HTTPException(
                status_code=402,
                detail="OpenAI quota exceeded. Please check your OpenAI account billing."
            )
        else:
            raise HTTPException(
                status_code=500,
                detail=f"Analysis failed: {error_msg}"
            )


@app.post("/api/upload")
async def upload_pdf(file: UploadFile = File(...)):
    """
    Accept a PDF upload and extract its text content.

    Returns the extracted text which the frontend loads into the textarea.
    """
    if not file.filename:
        raise HTTPException(status_code=400, detail="No file provided")

    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(
            status_code=400,
            detail="Only PDF files are supported. Please upload a .pdf file."
        )

    # Read file bytes (limit to 10MB)
    contents = await file.read()
    if len(contents) > 10 * 1024 * 1024:
        raise HTTPException(
            status_code=400,
            detail="File too large. Maximum size is 10MB."
        )

    try:
        text = extract_text_from_pdf(contents)
        return {"text": text}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to process PDF: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn

    port = int(os.environ.get("PORT", 8080))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=False)
