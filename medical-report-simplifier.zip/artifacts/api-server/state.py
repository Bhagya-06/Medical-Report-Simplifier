"""
LangGraph State Definition

This module defines the shared state object that flows through all nodes
in the LangGraph workflow. TypedDict ensures type safety across nodes.

LangGraph concept: State is the "memory" of the workflow — each node
receives the full state, modifies its relevant fields, and passes it on.
"""

from typing import TypedDict, Optional, List


class Finding(TypedDict):
    """A key finding extracted from the medical report."""
    title: str
    description: str


class MedicalTerm(TypedDict):
    """A medical term and its plain-language explanation."""
    term: str
    explanation: str


class AbnormalValue(TypedDict):
    """A potentially abnormal lab value with context."""
    test: str
    value: str
    reference_range: Optional[str]
    status: str  # "high", "low", or "borderline"
    interpretation: str


class WorkflowStep(TypedDict):
    """Records completion of each LangGraph node."""
    node: str
    status: str  # "completed" or "error"
    description: Optional[str]


class MedicalReportState(TypedDict):
    """
    The full state object that flows through the LangGraph workflow.

    LangGraph concept: All nodes share this single state object.
    Each node reads what it needs and writes its outputs back into state.
    The graph engine handles passing state between nodes automatically.
    """
    # Input
    original_report: str
    api_key: str

    # Node outputs (populated as the graph executes)
    extracted_findings: Optional[List[Finding]]
    medical_terms: Optional[List[MedicalTerm]]
    abnormal_values: Optional[List[AbnormalValue]]
    simplified_explanations: Optional[str]
    patient_summary: Optional[str]
    review_notes: Optional[str]
    final_output: Optional[dict]

    # Workflow tracking
    workflow_steps: List[WorkflowStep]
