"""
LangGraph Nodes

Each function here is a node in the LangGraph workflow.
Nodes receive the current state, call the OpenAI API for their task,
update the state with their results, and return the updated state.

LangGraph concept: Nodes are pure functions: State -> State.
They can do anything (call APIs, query databases, run code) and
return an updated state dictionary.
"""

import json
import re
from openai import OpenAI
from state import MedicalReportState, WorkflowStep


def _get_client(api_key: str) -> OpenAI:
    """Create an OpenAI client with the user-provided API key."""
    return OpenAI(api_key=api_key)


def _parse_json_response(content: str) -> dict | list:
    """
    Safely parse JSON from an LLM response.
    Handles markdown code blocks (```json ... ```) that models sometimes add.
    """
    content = content.strip()
    # Strip markdown code fences if present
    if content.startswith("```"):
        content = re.sub(r"^```(?:json)?\s*", "", content)
        content = re.sub(r"\s*```$", "", content)
    return json.loads(content)


def _add_step(state: MedicalReportState, node_name: str, status: str, description: str = None) -> list:
    """Helper to append a completed workflow step."""
    steps = list(state.get("workflow_steps", []))
    steps.append(WorkflowStep(node=node_name, status=status, description=description))
    return steps


# ─────────────────────────────────────────────────────────────────────────────
# Node 1: Extract Findings
# ─────────────────────────────────────────────────────────────────────────────

def extract_findings_node(state: MedicalReportState) -> dict:
    """
    Node 1: Extract Findings

    Identifies tests performed, diagnoses mentioned, measurements,
    and key clinical findings from the raw report text.

    LangGraph concept: This is the first node in the graph.
    It reads 'original_report' from state and writes 'extracted_findings'.
    """
    client = _get_client(state["api_key"])

    prompt = f"""You are a medical information extractor. Analyze this medical report and extract the key findings.

Return a JSON array of findings. Each finding must have:
- "title": short name of the finding (e.g., "Low Hemoglobin", "Elevated Cholesterol")
- "description": one sentence describing what was found and its value

Return ONLY the JSON array, no other text.

Medical Report:
{state["original_report"]}"""

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.1,
    )

    findings = _parse_json_response(response.choices[0].message.content)
    steps = _add_step(state, "Extract Findings", "completed", f"Found {len(findings)} key findings")

    return {
        "extracted_findings": findings,
        "workflow_steps": steps,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Node 2: Medical Terms
# ─────────────────────────────────────────────────────────────────────────────

def medical_terms_node(state: MedicalReportState) -> dict:
    """
    Node 2: Medical Terms

    Detects complex medical terminology and creates simple, plain-language
    explanations. For example: "Hypertension" → "High blood pressure".

    LangGraph concept: This node receives the state after Node 1 has run,
    so it can access the extracted_findings if needed. It reads the
    original_report and writes 'medical_terms'.
    """
    client = _get_client(state["api_key"])

    prompt = f"""You are a medical terminology explainer. Find all complex medical terms, abbreviations, and jargon in this report.

For each term, provide a simple plain-language explanation a patient can understand.

Return a JSON array. Each item must have:
- "term": the exact medical term or abbreviation from the report
- "explanation": plain-language explanation (1-2 sentences max)

Examples:
- {{"term": "Hypertension", "explanation": "High blood pressure — when the force of blood pushing against artery walls is too high."}}
- {{"term": "LDL", "explanation": "Low-density lipoprotein, often called 'bad cholesterol' — high levels can build up in arteries."}}

Return ONLY the JSON array. Include only terms that actually appear in the report.

Medical Report:
{state["original_report"]}"""

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.1,
    )

    terms = _parse_json_response(response.choices[0].message.content)
    steps = _add_step(state, "Medical Terms", "completed", f"Explained {len(terms)} medical terms")

    return {
        "medical_terms": terms,
        "workflow_steps": steps,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Node 3: Abnormal Values
# ─────────────────────────────────────────────────────────────────────────────

def abnormal_values_node(state: MedicalReportState) -> dict:
    """
    Node 3: Abnormal Values

    Identifies potentially abnormal lab values (high cholesterol, low hemoglobin,
    elevated blood sugar, etc.) and explains what they generally indicate.

    IMPORTANT: This node does NOT diagnose. It only explains what values
    generally indicate in educational terms.

    LangGraph concept: This node demonstrates how nodes can build on
    previous nodes' work (extracted_findings) while also reading raw input.
    """
    client = _get_client(state["api_key"])

    prompt = f"""You are a medical lab value analyzer. Identify any lab values or measurements in this report that are outside the normal reference range.

IMPORTANT: Do NOT provide medical diagnoses. Only explain what these values generally indicate educationally.

Return a JSON array. Each item must have:
- "test": the test name (e.g., "Hemoglobin", "Total Cholesterol")
- "value": the reported value with units (e.g., "10.2 g/dL")
- "reference_range": the normal range if mentioned (e.g., "13.5-17.5 g/dL"), or null if not stated
- "status": exactly one of "high", "low", or "borderline"
- "interpretation": one sentence explaining what this generally means educationally (not a diagnosis)

Only include values that are actually abnormal or borderline. Return empty array [] if all values are normal.
Return ONLY the JSON array.

Medical Report:
{state["original_report"]}"""

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.1,
    )

    abnormal = _parse_json_response(response.choices[0].message.content)
    steps = _add_step(state, "Abnormal Values", "completed", f"Identified {len(abnormal)} values outside normal range")

    return {
        "abnormal_values": abnormal,
        "workflow_steps": steps,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Node 4: Simplification
# ─────────────────────────────────────────────────────────────────────────────

def simplification_node(state: MedicalReportState) -> dict:
    """
    Node 4: Simplification

    Rewrites the entire medical report in plain, patient-friendly language.
    Replaces medical jargon with everyday words.

    Example transformation:
    "The patient exhibits elevated LDL cholesterol levels."
    → "Your bad cholesterol level is higher than the recommended range."

    LangGraph concept: This node uses state from multiple previous nodes
    to produce a comprehensive rewrite.
    """
    client = _get_client(state["api_key"])

    prompt = f"""You are a medical report simplifier. Rewrite this medical report in plain, friendly language that a patient with no medical background can understand.

Guidelines:
- Replace all medical jargon with simple everyday words
- Use "you" and "your" to make it personal
- Keep all the important information but make it accessible
- Explain what each finding means in practical terms
- Be reassuring but accurate — do NOT minimize important findings
- Do NOT provide medical diagnoses or treatment recommendations
- Write in clear paragraphs

Medical Report to simplify:
{state["original_report"]}"""

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3,
    )

    simplified = response.choices[0].message.content.strip()
    steps = _add_step(state, "Simplification", "completed", "Report rewritten in plain language")

    return {
        "simplified_explanations": simplified,
        "workflow_steps": steps,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Node 5: Patient Summary
# ─────────────────────────────────────────────────────────────────────────────

def patient_summary_node(state: MedicalReportState) -> dict:
    """
    Node 5: Patient Summary

    Generates a concise, actionable summary covering:
    - Main findings in plain language
    - Things to discuss with a doctor
    - Important observations to be aware of

    LangGraph concept: This node synthesizes outputs from multiple
    upstream nodes to produce a high-level summary.
    """
    client = _get_client(state["api_key"])

    findings_text = ""
    if state.get("extracted_findings"):
        findings_text = "\n".join([f"- {f['title']}: {f['description']}" for f in state["extracted_findings"]])

    abnormal_text = ""
    if state.get("abnormal_values"):
        abnormal_text = "\n".join([
            f"- {v['test']}: {v['value']} ({v['status'].upper()}) — {v['interpretation']}"
            for v in state["abnormal_values"]
        ])

    prompt = f"""You are a patient advocate creating a clear, reassuring summary of medical results.

Based on the analysis below, write a patient summary with these three sections:
1. **Main Findings**: The most important things from your test results (2-4 bullet points)
2. **Talk to Your Doctor About**: Specific questions or topics to raise at your next appointment (2-3 bullet points)  
3. **Important to Know**: Key observations and what they mean for your health (2-3 bullet points)

Use simple, supportive language. Be honest about concerning values but remain reassuring.
Do NOT diagnose conditions or recommend specific treatments.

Extracted Findings:
{findings_text if findings_text else "See original report"}

Values Outside Normal Range:
{abnormal_text if abnormal_text else "None identified"}

Original Report:
{state["original_report"]}"""

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3,
    )

    summary = response.choices[0].message.content.strip()
    steps = _add_step(state, "Patient Summary", "completed", "Patient-friendly summary generated")

    return {
        "patient_summary": summary,
        "workflow_steps": steps,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Node 6: Self Review
# ─────────────────────────────────────────────────────────────────────────────

def self_review_node(state: MedicalReportState) -> dict:
    """
    Node 6: Self Review

    Reviews all generated content for clarity, simplicity, and consistency.
    Identifies any improvements needed and generates review notes.

    LangGraph concept: This is a "quality gate" node that evaluates all
    previous outputs. In a more complex graph, it could loop back to
    earlier nodes to trigger rewrites if quality is insufficient.
    """
    client = _get_client(state["api_key"])

    prompt = f"""You are a quality reviewer for patient-facing medical content.

Review the following outputs and provide brief review notes:
1. Are the explanations clear and jargon-free?
2. Is the language appropriate for a patient (not a doctor)?
3. Are there any inconsistencies between sections?
4. Is anything potentially alarming stated without sufficient context?

Simplified Report:
{state.get("simplified_explanations", "")[:500]}...

Patient Summary:
{state.get("patient_summary", "")[:500]}...

Provide 2-3 sentences of review notes. Be concise.
"""

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2,
    )

    review = response.choices[0].message.content.strip()
    steps = _add_step(state, "Self Review", "completed", "Content reviewed for clarity and accuracy")

    return {
        "review_notes": review,
        "workflow_steps": steps,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Node 7: Final Output
# ─────────────────────────────────────────────────────────────────────────────

def final_output_node(state: MedicalReportState) -> dict:
    """
    Node 7: Final Output

    Combines all sections into one structured response ready to send
    to the frontend. This is the terminal node of the graph.

    LangGraph concept: The final node assembles the complete output.
    After this node, the graph execution ends and results are returned.
    """
    steps = _add_step(state, "Final Output", "completed", "All sections assembled into final response")

    final = {
        "findings": state.get("extracted_findings", []),
        "medical_terms": state.get("medical_terms", []),
        "abnormal_values": state.get("abnormal_values", []),
        "simplified_report": state.get("simplified_explanations", ""),
        "patient_summary": state.get("patient_summary", ""),
        "review_notes": state.get("review_notes"),
        "workflow_steps": steps,
    }

    return {
        "final_output": final,
        "workflow_steps": steps,
    }
