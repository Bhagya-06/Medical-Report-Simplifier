import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { AnalysisResult } from "@workspace/api-client-react/src/generated/api.schemas";
import { Activity, BookOpen, AlertTriangle, FileText, CheckCircle2, User, ChevronRight } from "lucide-react";

interface ResultsDisplayProps {
  data: AnalysisResult;
}

export function ResultsDisplay({ data }: ResultsDisplayProps) {
  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-20">
      
      {/* Patient Summary - Most Prominent */}
      <Card className="border-2 border-primary shadow-md overflow-hidden bg-gradient-to-br from-white to-primary/5">
        <div className="bg-primary px-6 py-4 text-primary-foreground flex items-center gap-3">
          <User className="h-6 w-6" />
          <h2 className="text-xl font-bold tracking-tight">The Bottom Line</h2>
        </div>
        <CardContent className="p-6 sm:p-8">
          <p className="text-lg leading-relaxed text-foreground font-medium">
            {data.patient_summary}
          </p>
        </CardContent>
      </Card>

      {/* Simplified Report */}
      <Card className="shadow-sm border-border">
        <CardHeader className="bg-muted/30 border-b border-border pb-4">
          <CardTitle className="flex items-center gap-2 text-lg text-foreground">
            <FileText className="h-5 w-5 text-primary" />
            Simplified Report
          </CardTitle>
          <CardDescription>A plain-language translation of the entire document</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="prose prose-slate max-w-none text-foreground/90">
            {data.simplified_report.split('\n').map((paragraph, i) => (
              <p key={i} className="mb-4 last:mb-0">{paragraph}</p>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Abnormal Values */}
      {data.abnormal_values.length > 0 && (
        <Card className="shadow-sm border-border border-l-4 border-l-amber-500">
          <CardHeader className="bg-amber-50/50 border-b border-border pb-4">
            <CardTitle className="flex items-center gap-2 text-lg text-foreground">
              <AlertTriangle className="h-5 w-5 text-amber-500" />
              Values Outside Normal Range
            </CardTitle>
            <CardDescription>Test results that were flagged as high, low, or borderline</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-muted/30">
                  <TableRow>
                    <TableHead className="w-[200px]">Test</TableHead>
                    <TableHead>Value</TableHead>
                    <TableHead>Reference</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>What this means</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.abnormal_values.map((item, i) => (
                    <TableRow key={i}>
                      <TableCell className="font-medium">{item.test}</TableCell>
                      <TableCell>{item.value}</TableCell>
                      <TableCell className="text-muted-foreground">{item.reference_range || "N/A"}</TableCell>
                      <TableCell>
                        <Badge 
                          variant="outline" 
                          className={
                            item.status.toLowerCase().includes('high') ? "bg-red-50 text-red-700 border-red-200" :
                            item.status.toLowerCase().includes('low') ? "bg-blue-50 text-blue-700 border-blue-200" :
                            "bg-amber-50 text-amber-700 border-amber-200"
                          }
                        >
                          {item.status.toUpperCase()}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm">{item.interpretation}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Key Findings */}
      {data.findings.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-border">
            <Activity className="h-5 w-5 text-primary" />
            <h3 className="text-lg font-semibold text-foreground">Key Findings</h3>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {data.findings.map((finding, i) => (
              <Card key={i} className="shadow-sm border-border bg-card">
                <CardHeader className="p-4 pb-2">
                  <CardTitle className="text-base text-primary">{finding.title}</CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <p className="text-sm text-muted-foreground">{finding.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Medical Terms Explained */}
      {data.medical_terms.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-border">
            <BookOpen className="h-5 w-5 text-primary" />
            <h3 className="text-lg font-semibold text-foreground">Medical Dictionary</h3>
          </div>
          <Accordion type="multiple" className="w-full bg-card rounded-lg border border-border shadow-sm">
            {data.medical_terms.map((term, i) => (
              <AccordionItem key={i} value={`term-${i}`} className="px-4 border-b last:border-0">
                <AccordionTrigger className="hover:no-underline py-4">
                  <span className="font-semibold text-left">{term.term}</span>
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-4">
                  {term.explanation}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      )}

      {/* Workflow Steps */}
      <Card className="shadow-sm border-border overflow-hidden">
        <CardHeader className="bg-muted/30 border-b border-border py-3">
          <CardTitle className="text-sm font-medium flex items-center gap-2 text-muted-foreground">
            <CheckCircle2 className="h-4 w-4" />
            Analysis Process Log
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-border">
            {data.workflow_steps.map((step, i) => (
              <div key={i} className="flex items-center justify-between p-3 text-sm">
                <div className="flex items-center gap-3">
                  <span className="text-muted-foreground text-xs font-mono">{i + 1}</span>
                  <span className="font-medium text-foreground">{step.node}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className={step.status === 'completed' ? "bg-green-50 text-green-700 border-green-200" : "bg-red-50 text-red-700 border-red-200"}>
                    {step.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

    </div>
  );
}
