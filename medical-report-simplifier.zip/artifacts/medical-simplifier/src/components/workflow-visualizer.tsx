import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Check, CircleDashed, Loader2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface WorkflowVisualizerProps {
  isPending: boolean;
  isError: boolean;
}

const NODES = [
  "Extract Findings",
  "Medical Terms",
  "Abnormal Values",
  "Simplification",
  "Patient Summary",
  "Self Review",
  "Final Output"
];

export function WorkflowVisualizer({ isPending, isError }: WorkflowVisualizerProps) {
  const [completedIndex, setCompletedIndex] = useState(-1);

  useEffect(() => {
    if (isPending) {
      setCompletedIndex(-1);
      
      const interval = setInterval(() => {
        setCompletedIndex((prev) => {
          if (prev < NODES.length - 2) {
            return prev + 1;
          }
          return prev;
        });
      }, 1500);
      
      return () => clearInterval(interval);
    } else if (!isError && !isPending) {
      setCompletedIndex(NODES.length - 1);
    }
  }, [isPending, isError]);

  if (!isPending && completedIndex === -1) return null;

  return (
    <Card className="border border-primary/20 shadow-sm bg-white overflow-hidden mt-6">
      <div className="bg-primary/5 px-6 py-4 border-b border-primary/10">
        <h3 className="font-semibold text-primary flex items-center gap-2">
          {isPending ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Running Analysis...
            </>
          ) : (
            <>
              <Check className="h-4 w-4 text-green-600" />
              Analysis Complete
            </>
          )}
        </h3>
        <p className="text-xs text-muted-foreground mt-1">
          Our AI is reviewing your report step-by-step to ensure accuracy and clarity.
        </p>
      </div>
      <CardContent className="p-6">
        <div className="flex flex-col gap-4">
          {NODES.map((node, i) => {
            const isCompleted = i <= completedIndex;
            const isCurrent = i === completedIndex + 1 && isPending;
            
            return (
              <div key={node} className="flex items-center gap-3">
                <div className="relative">
                  {isCompleted ? (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="h-6 w-6 rounded-full bg-primary flex items-center justify-center text-primary-foreground z-10 relative shadow-sm"
                    >
                      <Check className="h-3.5 w-3.5" />
                    </motion.div>
                  ) : isCurrent ? (
                    <div className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center text-primary z-10 relative">
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    </div>
                  ) : (
                    <div className="h-6 w-6 rounded-full bg-muted flex items-center justify-center text-muted-foreground z-10 relative">
                      <CircleDashed className="h-3.5 w-3.5" />
                    </div>
                  )}
                  {i < NODES.length - 1 && (
                    <div className="absolute top-6 left-1/2 -translate-x-1/2 w-[2px] h-[16px] bg-border" />
                  )}
                </div>
                <span
                  className={`text-sm font-medium ${
                    isCompleted
                      ? "text-foreground"
                      : isCurrent
                      ? "text-primary"
                      : "text-muted-foreground"
                  }`}
                >
                  {node}
                </span>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
