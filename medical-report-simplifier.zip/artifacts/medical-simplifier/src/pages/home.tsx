import React, { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { WorkflowVisualizer } from "@/components/workflow-visualizer";
import { ResultsDisplay } from "@/components/results-display";
import { useToast } from "@/hooks/use-toast";
import { useAnalyzeReport } from "@workspace/api-client-react";
import { HeartPulse, Upload, FileText, Key, Stethoscope, ChevronRight, FileUp } from "lucide-react";

const SAMPLE_1 = `Complete Blood Count Report
Patient: John Doe | Date: 2024-01-15

Hemoglobin: 10.2 g/dL (Reference: 13.5-17.5 g/dL) - LOW
Hematocrit: 31% (Reference: 41-53%) - LOW
WBC: 11.8 K/uL (Reference: 4.5-11.0 K/uL) - HIGH
Platelets: 145 K/uL (Reference: 150-400 K/uL) - BORDERLINE LOW

Lipid Panel:
Total Cholesterol: 245 mg/dL (Reference: Below 200 mg/dL) - HIGH
LDL Cholesterol: 165 mg/dL (Reference: Below 100 mg/dL) - HIGH
HDL Cholesterol: 38 mg/dL (Reference: Above 40 mg/dL) - LOW

Fasting Blood Sugar: 128 mg/dL (Reference: Below 100 mg/dL) - HIGH (Pre-diabetic range)

Assessment: The patient exhibits mild normocytic anemia, hypercholesterolemia, leukocytosis, and impaired fasting glucose consistent with pre-diabetes.`;

const SAMPLE_2 = `Thyroid Function & Metabolism Panel
Patient: Jane Smith | Date: 2023-11-20

TSH (Thyroid Stimulating Hormone): 5.8 mIU/L (Reference: 0.4-4.0 mIU/L) - HIGH
Free T4: 0.8 ng/dL (Reference: 0.9-2.3 ng/dL) - LOW
Free T3: 2.1 pg/mL (Reference: 2.3-4.2 pg/mL) - LOW
Thyroid Peroxidase Antibodies (TPOAb): 150 IU/mL (Reference: <9 IU/mL) - HIGH

HbA1c: 6.8% (Reference: <5.7%) - HIGH
Estimated Average Glucose (eAG): 148 mg/dL

Vitamin D (25-OH): 18 ng/mL (Reference: 30-100 ng/mL) - DEFICIENT

Assessment: Laboratory findings are consistent with Hashimoto's thyroiditis presenting as overt primary hypothyroidism. Elevated HbA1c indicates poor glycemic control in the diabetic range. Concurrent severe Vitamin D deficiency noted. Recommend endocrinology consultation.`;

export default function Home() {
  const [apiKey, setApiKey] = useState("");
  const [reportText, setReportText] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const mutation = useAnalyzeReport();

  const handleAnalyze = () => {
    if (!apiKey.trim()) {
      toast({
        title: "API Key Required",
        description: "Please enter your OpenAI API key in the sidebar.",
        variant: "destructive",
      });
      return;
    }
    if (!reportText.trim()) {
      toast({
        title: "Report Required",
        description: "Please paste or upload a medical report.",
        variant: "destructive",
      });
      return;
    }

    mutation.mutate({
      data: {
        api_key: apiKey,
        report_text: reportText,
      },
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Failed to upload file");
      }

      const data = await response.json();
      setReportText(data.text);
      toast({
        title: "File uploaded successfully",
        description: "We've extracted the text. You can now analyze it.",
      });
    } catch (err) {
      toast({
        title: "Upload Failed",
        description: "Could not read the PDF file. Please try pasting the text instead.",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
      // Reset input
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col font-sans selection:bg-primary/20">
      {/* Header */}
      <header className="border-b border-border bg-white sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 bg-primary/10 rounded-xl flex items-center justify-center text-primary">
              <HeartPulse className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground leading-none tracking-tight">Medical Report Simplifier AI</h1>
              <p className="text-sm text-muted-foreground hidden sm:block">Understand your medical reports in plain language</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto w-full p-4 md:p-6 lg:p-8 flex flex-col lg:flex-row gap-6 lg:gap-8">
        
        {/* Sidebar */}
        <aside className="w-full lg:w-80 flex-shrink-0 space-y-6">
          <Card className="border-border shadow-sm bg-card">
            <CardContent className="p-5 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="api-key" className="flex items-center gap-2 text-foreground font-semibold">
                  <Key className="h-4 w-4 text-muted-foreground" />
                  OpenAI API Key
                </Label>
                <Input
                  id="api-key"
                  type="password"
                  placeholder="sk-..."
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  className="bg-background focus-visible:ring-primary font-mono text-sm"
                  data-testid="input-api-key"
                />
                <p className="text-xs text-muted-foreground">Your key is kept securely in your browser and never stored.</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border shadow-sm bg-card">
            <CardContent className="p-5 space-y-5">
              <div>
                <Label className="flex items-center gap-2 text-foreground font-semibold mb-3">
                  <FileUp className="h-4 w-4 text-muted-foreground" />
                  Upload PDF Report
                </Label>
                <div className="flex items-center gap-3">
                  <input
                    type="file"
                    accept=".pdf"
                    className="hidden"
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    data-testid="input-file-upload"
                  />
                  <Button 
                    variant="outline" 
                    className="w-full border-dashed border-2 hover:border-primary/50 hover:bg-primary/5"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploading || mutation.isPending}
                    data-testid="button-upload"
                  >
                    {isUploading ? "Reading file..." : "Choose PDF File"}
                  </Button>
                </div>
              </div>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-border" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-card px-2 text-muted-foreground">Or try a sample</span>
                </div>
              </div>

              <div className="space-y-2">
                <Button 
                  variant="secondary" 
                  className="w-full justify-start text-left font-normal bg-secondary hover:bg-secondary/80 text-foreground"
                  onClick={() => setReportText(SAMPLE_1)}
                  disabled={mutation.isPending}
                  data-testid="button-sample-blood"
                >
                  <FileText className="h-4 w-4 mr-2 text-primary" />
                  Blood Work Sample
                </Button>
                <Button 
                  variant="secondary" 
                  className="w-full justify-start text-left font-normal bg-secondary hover:bg-secondary/80 text-foreground"
                  onClick={() => setReportText(SAMPLE_2)}
                  disabled={mutation.isPending}
                  data-testid="button-sample-thyroid"
                >
                  <FileText className="h-4 w-4 mr-2 text-primary" />
                  Thyroid & Diabetes Sample
                </Button>
              </div>
            </CardContent>
          </Card>
        </aside>

        {/* Main Workspace */}
        <section className="flex-1 flex flex-col min-w-0">
          {!mutation.data && !mutation.isPending && (
            <div className="bg-primary/5 border border-primary/10 rounded-xl p-6 mb-6 flex gap-4 items-start">
              <div className="bg-primary/10 p-3 rounded-full text-primary shrink-0">
                <Stethoscope className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-primary mb-1">Your Personal Medical Interpreter</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Medical reports are written for doctors, not patients. Paste your lab results or clinical notes below, and our AI will translate the jargon, explain abnormal values, and provide a clear, calm summary of what it all means.
                </p>
              </div>
            </div>
          )}

          <div className="flex-1 flex flex-col gap-4">
            <Label htmlFor="report-input" className="sr-only">Report Text</Label>
            <Textarea
              id="report-input"
              placeholder="Paste your medical report text here..."
              className="min-h-[250px] resize-y p-5 font-mono text-sm shadow-inner bg-white focus-visible:ring-primary/50"
              value={reportText}
              onChange={(e) => setReportText(e.target.value)}
              disabled={mutation.isPending}
              data-testid="textarea-report"
            />
            
            <div className="flex justify-end mt-2">
              <Button 
                size="lg" 
                className="w-full sm:w-auto px-8 gap-2 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold shadow-md transition-all hover:-translate-y-0.5"
                onClick={handleAnalyze}
                disabled={mutation.isPending || !reportText.trim()}
                data-testid="button-analyze"
              >
                {mutation.isPending ? "Analyzing..." : "Analyze Report"}
                {!mutation.isPending && <ChevronRight className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          {mutation.isError && (
            <div className="mt-6 p-4 bg-destructive/10 text-destructive border border-destructive/20 rounded-lg text-sm font-medium animate-in slide-in-from-bottom-2">
              {mutation.error?.error || "Analysis failed. Please check your API key and try again."}
            </div>
          )}

          <WorkflowVisualizer isPending={mutation.isPending} isError={mutation.isError} />

          {mutation.data && !mutation.isPending && (
            <div className="mt-10" data-testid="results-container">
              <ResultsDisplay data={mutation.data} />
            </div>
          )}
        </section>
        
      </main>
    </div>
  );
}
